package com.ricardo.modelos;

public class Habitacion {

	private int hid;
	private String calle;
	private int m2;
	
	public Habitacion(int hid, String calle, int m2) {
		this.hid = hid;
		this.calle = calle;
		this.m2 = m2;
	}

	public int getHid() {
		return hid;
	}

	public void setHid(int hid) {
		this.hid = hid;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public int getM2() {
		return m2;
	}

	public void setM2(int m2) {
		this.m2 = m2;
	}
	
	
	
	
}
