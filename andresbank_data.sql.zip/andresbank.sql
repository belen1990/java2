-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 23-11-2018 a las 08:14:24
-- Versión del servidor: 5.7.11
-- Versión de PHP: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `andresbank`
--
CREATE DATABASE IF NOT EXISTS `andresbank` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `andresbank`;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`uid`, `nombre`, `dni`, `pin`, `nomina`) VALUES
(1, 'Pepe', '12345678P', 'pppp', NULL),
(2, 'Josefa', '123456789J', 'jjjj', NULL),
(3, 'Maria', '12345678M', 'mmmm', NULL);

--
-- Volcado de datos para la tabla `cliente_cuenta`
--

INSERT INTO `cliente_cuenta` (`cliente`, `cuenta`) VALUES
(1, 9),
(3, 10);

--
-- Volcado de datos para la tabla `cuenta`
--

INSERT INTO `cuenta` (`cid`, `nombre`, `numero`, `saldo`) VALUES
(1, 'Cuenta 1', '12345678912345678901', 1000),
(2, 'Cuenta 2', '32345678912345678902', 20000),
(3, 'Cuenta 3', '62345678912345678906', 5000),
(4, 'Casa', '12345678912345678999', 100),
(5, 'Casa2', '12345678912345678999', 100),
(6, 'Casa', '12345678912345678900', 100),
(7, 'NuevaC', '12345678912345678999', 1000),
(8, 'NuevaC', '12345678912345678999', 1000),
(9, 'CasaX', '12345678912345678900', 1000),
(10, 'Casa M', '12345678912345678900', 100);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
