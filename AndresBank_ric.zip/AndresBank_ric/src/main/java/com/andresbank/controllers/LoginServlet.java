package com.andresbank.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.andresbank.ddbb.DDBB;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("login.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String dnirec=request.getParameter("dni");
		String passrec=request.getParameter("pass");
		
		if(DDBB.getInstance().getUserByDNIAndPass(dnirec,passrec)!=null) {
			response.sendRedirect("cuentas");
			request.getSession().setAttribute("dni", dnirec);
		}else {
			request.setAttribute("mensaje_error", "Usuario incorrecto");
			doGet(request, response);	
		}
		
		
	}

}
